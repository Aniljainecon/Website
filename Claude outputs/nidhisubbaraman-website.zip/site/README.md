# nidhisubbaraman.com

Nidhi Subbaraman's portfolio site. Plain HTML, CSS, and a few lines of JS — no
build step, no framework, no dependencies. It's meant to be hosted for free
on GitHub Pages, the same way anilkjain.com is.

## Files

- `index.html` — the whole site (one page)
- `style.css` — all styling, including dark mode (follows the visitor's
  system setting automatically)
- `assets/nidhi-subbaraman.jpg` — headshot
- `favicon.svg` — browser tab icon
- `robots.txt`, `sitemap.xml` — basic SEO plumbing
- `CNAME` — tells GitHub Pages which custom domain to serve this under

## Making a change

Everything is in `index.html`. To add a new clip, copy one `<li>` inside the
relevant `<ul class="clip-list">` and edit the headline text and the `href`.
For BuzzFeed/Globe/NBC-style entries with a description and year, copy one of
the `<li>` blocks under `.described` instead — it has an extra `<span
class="year">` and `<p>`.

No local tools are required to preview a change: just open `index.html`
directly in a browser after editing it. If you want a local server (closer
to how it'll behave live), run this from inside the folder:

```
python3 -m http.server 8000
```

then visit `http://localhost:8000`.

## Deploying to GitHub Pages

1. Create a new **public** repository on GitHub (e.g. `nidhisubbaraman/website`).
2. Push this folder's contents to its `main` branch:

   ```
   git init
   git add .
   git commit -m "Initial site"
   git branch -M main
   git remote add origin https://github.com/<your-username>/<repo-name>.git
   git push -u origin main
   ```

3. In the repo on GitHub: **Settings → Pages** → under "Build and
   deployment", set **Source** to "Deploy from a branch", branch `main`,
   folder `/ (root)`. Save.
4. GitHub will publish the site at `https://<your-username>.github.io/<repo-name>/`
   within a minute or two — confirm it works before moving on to the custom
   domain step below.

Every time you push a change to `main`, the live site updates automatically
within a minute, no separate deploy step.

## Pointing nidhisubbaraman.com at it

The domain currently resolves through Squarespace. To move it over without
downtime:

1. **Find out where the domain is registered.** If it was bought through
   Squarespace itself, it's at Squarespace Domains. Check under
   Squarespace → Settings → Domains. You do **not** need to transfer the
   domain to a new registrar to do this — you only need to change its DNS
   records, which you can do from wherever it's registered.

2. **Add these DNS records** (this repo's `CNAME` file is set to
   `www.nidhisubbaraman.com`, matching the current live URL):

   | Type  | Host / Name | Value                          |
   |-------|-------------|--------------------------------|
   | CNAME | www         | `<your-username>.github.io`    |
   | A     | @ (apex)    | `185.199.108.153`               |
   | A     | @ (apex)    | `185.199.109.153`               |
   | A     | @ (apex)    | `185.199.110.153`               |
   | A     | @ (apex)    | `185.199.111.153`               |

   (Those four A records are GitHub Pages' standard apex-domain IPs — same
   for every GitHub Pages site, not specific to this repo. Double-check them
   against GitHub's current docs at the time you do this, in case they've
   changed: docs.github.com → "Managing a custom domain for your GitHub
   Pages site".)

3. Back in the repo's **Settings → Pages**, enter `www.nidhisubbaraman.com`
   under "Custom domain" and save. GitHub will verify DNS (can take up to a
   few hours to propagate) and then offer to **Enforce HTTPS** — turn that
   on once it's available.

4. Once the new site is confirmed live at `www.nidhisubbaraman.com`, remove
   the site from Squarespace (or just let the subscription lapse) to stop
   being billed for hosting you no longer need.

DNS changes can take anywhere from a few minutes to ~24 hours to fully
propagate. The old Squarespace site keeps serving traffic until the new DNS
records take effect, so there's no gap where the domain is down.

## Updating the clips over time

There's no CMS here on purpose — for a page that changes a few times a year,
editing a line of HTML directly on GitHub is simpler than maintaining a
content-management system. To add a clip without any local setup:

1. Go to the file on GitHub (e.g. `index.html`) and click the pencil
   (edit) icon.
2. Copy/paste an existing `<li>` and change the text and link.
3. Commit directly to `main` — the live site updates automatically.
